﻿

Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Imports MySql.Data

'Imports System.Data.m
Public Class Form1
    Dim MysqlConn As MySqlConnection
    Dim ContactsCommand As New MySqlCommand
    Dim ContactsAdapter As New MySqlDataAdapter
    Dim ContactsData As New DataTable
    Dim SQL As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' DataGridView1.ClearSelection()
        'DataGridView1.Refresh()
        'DataGridView1.DataBindings.Clear()
        'DataGridView1.Rows.Clear()
        ' DataGridView1.DataSource = Nothing

        'DataGridView1.DataSource = Nothing
        'DataGridView1.DataSource.Clear()
        If TextBox1.Text = "" Then
            MsgBox("You have not completed the ID field. This is a mandatory field.")
            TextBox1.Focus()


        Else
            findEmp()
        End If

    End Sub
    Private Sub findEmp()
        dbcon()

        ' Define the SQL to grab data from table.
        SQL = "SELECT * FROM employee WHERE emp_id Like '" & TextBox1.Text & "'"

        'Connection String
        'MysqlConn.ConnectionString = "server=localhost;" _
        ' & "user id=root;" _
        ' & "password=;" _
        ' & "database=db"


        ' Try, Catch, Finally
        Try
            'MysqlConn.Open()

            ContactsCommand.Connection = MysqlConn
            ContactsCommand.CommandText = SQL

            ContactsAdapter.SelectCommand = ContactsCommand
            ContactsAdapter.Fill(ContactsData)



            DataGridView1.DataSource = ContactsData

        Catch myerror As MySqlException
            MessageBox.Show("Cannot connect to database: " & myerror.Message)
        Finally
            MysqlConn.Close()
            MysqlConn.Dispose()
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        ' Define the SQL to grab data from table.
        SQL = "SELECT emp_id,emp_fname,emp_lname FROM employee"

        'Connection String
        'MysqlConn.ConnectionString = "server=localhost;" _
        ' & "user id=root;" _
        ' & "password=;" _
        ' & "database=db"
        dbcon()
      
        ' Try, Catch, Finally
        Try
            'MysqlConn.Open()

            ContactsCommand.Connection = MysqlConn
            ContactsCommand.CommandText = SQL

            ContactsAdapter.SelectCommand = ContactsCommand
            ContactsAdapter.Fill(ContactsData)



            DataGridView1.DataSource = ContactsData

        Catch myerror As MySqlException
            MessageBox.Show("Cannot connect to database: " & myerror.Message)
        Finally
            MysqlConn.Close()
            MysqlConn.Dispose()
        End Try
    End Sub
    Function dbcon()


        MysqlConn = New MySqlConnection()

        'Connection String
        MysqlConn.ConnectionString = "server=localhost;" _
         & "user id=root;" _
         & "password=;" _
         & "database=db"

        'https://remotemysql.com/databases.php

        '  MysqlConn.ConnectionString = "server=remotemysql.com;" _
        '& "user id=5HKbYeNpf8;" _
        '& "password=Ek1dwlDAys;" _
        '& "database=5HKbYeNpf8"
        ' Try, Catch, Finally
        Try
            MysqlConn.Open()

        Catch errmsg As MySqlException
            MessageBox.Show("Cannot connect to database: " & errmsg.Message)
        End Try
        Return 0
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'dbcon()
        If TextBox5.Text = "" Then
            MsgBox("You have not completed the ID field. This is a mandatory field.")
            TextBox5.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("You have not entered your last name. This is a mandatory field.")
            TextBox3.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("You have not entered your first name(s). This is a mandatory field.")
            TextBox2.Focus()
        
        Else
            MsgBox(updateRecord("INSERT INTO employee (emp_id, emp_fname,emp_lname,dob) VALUES ('" & TextBox5.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "')"))

        End If

    End Sub
    Function updateRecord(ByVal query As String) As Integer
        Dim rowsEffected As Integer = 0

        dbcon()
        'Dim connection As New MySqlConnection(MysqlConn)
        Dim cmd As New MySqlCommand(query, MysqlConn)
        'MysqlConn.Open()

        rowsEffected = cmd.ExecuteNonQuery()
        MysqlConn.Close()
        Return rowsEffected
        'MysqlConn.Close()

    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "yyyy-MM-dd"
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBox5.Text = "" Then
            MsgBox("You have not completed the ID field. This is a mandatory field.")
            TextBox5.Focus()
        ElseIf TextBox3.Text = "" Then
            MsgBox("You have not entered your last name. This is a mandatory field.")
            TextBox3.Focus()
        ElseIf TextBox2.Text = "" Then
            MsgBox("You have not entered your first name(s). This is a mandatory field.")
            TextBox2.Focus()

        Else
            MsgBox(updateRecord("UPDATE employee SET emp_fname='" & TextBox2.Text & "', emp_lname='" & TextBox3.Text & "',dob='" & DateTimePicker1.Text & "' WHERE emp_id ='" & TextBox5.Text & "'"))
        End If

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox5.Text = "" Then
            MsgBox("You have not completed the ID field. This is a mandatory field.")
            TextBox5.Focus()
        Else
            MsgBox(updateRecord("DELETE FROM employee WHERE emp_id ='" & TextBox5.Text & "'"))
        End If

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ClearTextBox()
    End Sub
    Public Sub ClearTextBox()
        Dim xTextBox As TextBox = Nothing

        For Each xObject As Object In Me.Controls
            If TypeOf xObject Is TextBox Then
                xTextBox = xObject
                xTextBox.Text = ""
            End If
        Next
    End Sub
    Private Sub AutoNumberNo()
        'Dim myReader As MySqlDataReader
        dbcon()
        Dim sql As String = "SELECT MAX(emp_id) FROM employee "
        Dim myCommand As New MySqlCommand(sql, MysqlConn)
        'myConnection.Open()
        Dim myReader As MySqlDataReader
        myReader = myCommand.ExecuteReader()
        Dim temp As String = ""
        Try
            While myReader.Read()
                Dim str As String = myReader.GetString(0)
                str = str.Remove(0, 3)
                temp = CInt(Int(str)) + 1
                If (temp <= 9) Then
                    str = "EMP00" + temp
                ElseIf (temp <= 99) Then
                    str = "EMP0" + temp
                Else
                    str = "EMP" + temp
                End If
                MsgBox(str)
                TextBox5.Text = str
            End While
        Finally
            myReader.Close()
            MysqlConn.Close()
        End Try


        

        
        ' result will appear in textbox txtId
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        ClearTextBox()
        AutoNumberNo()
    End Sub
End Class
